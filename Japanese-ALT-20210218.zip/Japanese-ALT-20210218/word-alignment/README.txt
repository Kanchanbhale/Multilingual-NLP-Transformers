Files extracted from annotated English-Japanese ALT data

- data_ja.en-raw : original English sentences
- data_ja.ja-raw : original Japanese sentences

- data_ja.en-tok : tokenized English sentences
- data_ja.ja-tok : tokenized Japanese sentences
    # "(" is replaces by -LRB- and ")" is replaced by -RRB-

- data_ja.en-ja  : token alignment between data_ja.[en|ja]-tok
    # Moses format,
    # English token index - Japanese token index, starting from 0.
