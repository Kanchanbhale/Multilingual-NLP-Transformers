
Japanese ALT 

				Masao Utiyama
				Thu Feb 18 11:05:31 JST 2021

* Introduction

This is the Japanese Treebank of the Asian Language Treebank (ALT)
Corpus. English texts sampled from English Wikinews were
available under a Creative Commons Attribution 2.5
License. Please refer to
http://www2.nict.go.jp/astrec-att/member/mutiyama/ALT/index.html
for details.

The Japanese ALT is the annotated treebank for about 20k
Japanese translations of English Wikinews Article sentences.

NICT released Japanese ALT as a

Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0) License
https://creativecommons.org/licenses/by-nc-sa/4.0/


* Contents

Japanese-ALT-Reviewed.txt	Two annotaters for each sentence tree
Japanese-ALT-Draft.txt		One annotater for each sentence tree
morph-analysis.txt		Mecab IPA-DIC morphological analysis data
word-alignment			English -> Japanese word alignment data
Japanese-ALT-with-NE-20200401.sexp	Tree annotated with Named Entities

Note that some sentences are missing.


* Disclaimer

[1] The content of the selected English Wikinews articles have been translated for this corpus. English texts sampled from English Wikinews were available under a Creative Commons Attribution 2.5 License. Users of the corpus are requested to take careful consideration when encountering any instances of defamation, discriminatory terms, or personal information that might be found within the corpus. Users of the corpus are advised to read Terms of Use in https://en.wikinews.org/wiki/Main_Page carefully to ensure proper usage.

[2] NICT bears no responsibility for the contents of the corpus and the lexicon and assumes no liability for any direct or indirect damage or loss whatsoever that may be incurred as a result of using the corpus or the lexicon.

[3] If any copyright infringement or other problems are found in the corpus or the lexicon, please contact us at alt-info[at]khn[dot]nict[dot]go[dot]jp. We will review the issue and undertake appropriate measures when needed.


