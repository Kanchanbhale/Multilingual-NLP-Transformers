
English ALT 

				Masao Utiyama
				Thu Feb 18 11:08:45 JST 2021

* Introduction

This is the English Treebank of the Asian Language Treebank
(ALT) Corpus. English texts sampled from English Wikinews were
available under a Creative Commons Attribution 2.5
License. Please refer to
http://www2.nict.go.jp/astrec-att/member/mutiyama/ALT/index.html
for details.

The English ALT is the annotated treebank for about 20k English
Wikinews Article sentences.

NICT released English ALT as a

Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0) License
https://creativecommons.org/licenses/by-nc-sa/4.0/


* Contents

English-ALT-Reviewed.txt	Two annotaters for each sentence
English-ALT-Draft.txt		One annotater for each sentence
English-ALT.pdf			Annotation guideline
English-ALT-with-NE-20200401.sexp	Tree annotated with NE

wc -l English-ALT-*
  11259 English-ALT-Draft.txt
   8639 English-ALT-Reviewed.txt
  19898 total

Note that some sentences are missing.


Format:

SNT_ID<TAB>S-EXP

Examples:

SNT.80188.1	(S (S (BASENP (NNP Italy)) (VP (VBP have) (VP (VP (VP (VBN defeated) (BASENP (NNP Portugal))) (ADVP (RB 31-5))) (PP (IN in) (NP (BASENP (NNP Pool) (NNP C)) (PP (IN of) (NP (BASENP (DT the) (NN 2007) (NNP Rugby) (NNP World) (NNP Cup)) (PP (IN at) (NP (BASENP (NNP Parc) (FW des) (NNP Princes)) (COMMA ,) (BASENP (NNP Paris) (COMMA ,) (NNP France))))))))))) (PERIOD .))
SNT.80188.2	(S (S (BASENP (NNP Andrea) (NNP Masi)) (VP (VP (VP (VBD opened) (BASENP (DT the) (NN scoring))) (PP (IN in) (BASENP (DT the) (JJ fourth) (NN minute)))) (PP (IN with) (NP (BASENP (DT a) (NN try)) (PP (IN for) (BASENP (NNP Italy))))))) (PERIOD .))
SNT.80188.3	(S (S (S (PP (IN Despite) (S (VP (VP (VBG controlling) (BASENP (DT the) (NN game))) (PP (IN for) (NP (BASENP (JJ much)) (PP (IN of) (BASENP (DT the) (JJ first) (NN half)))))))) (COMMA ,) (S (BASENP (NNP Italy)) (VP (VP (MD could) (RB not)) (VP (VP (VB score) (BASENP (DT any) (JJ other) (NN tries))) (PP (IN before) (BASENP (DT the) (NN interval))))))) (CC but) (S (BASENP (NNP David) (NNP Bortolussi)) (VP (VP (VBD kicked) (BASENP (NN three) (NNS penalties))) (S (VP (TO to) (VP (VB extend) (BASENP (PRPD their) (NN lead)))))))) (PERIOD .))


* Disclaimer

[1] English texts sampled from English Wikinews were available under a Creative Commons Attribution 2.5 License. Users of the corpus are requested to take careful consideration when encountering any instances of defamation, discriminatory terms, or personal information that might be found within the corpus. Users of the corpus are advised to read Terms of Use in https://en.wikinews.org/wiki/Main_Page carefully to ensure proper usage.

[2] NICT bears no responsibility for the contents of the corpus and the lexicon and assumes no liability for any direct or indirect damage or loss whatsoever that may be incurred as a result of using the corpus or the lexicon.

[3] If any copyright infringement or other problems are found in the corpus or the lexicon, please contact us at alt-info[at]khn[dot]nict[dot]go[dot]jp. We will review the issue and undertake appropriate measures when needed.


